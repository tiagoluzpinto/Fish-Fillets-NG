package interfaces;

/**
 * Interface para todos os GameObjects que são afetados pela gravidade, 
 * fazendo com que afundem.
 * * O GameEngine irá chamar o método applyGravity() em cada "tick"
 * para todos os objetos que implementam esta interface.
 */
public interface IsAffectedByGravity {

	/**
	 * O objeto é responsável por verificar se pode cair
	 * (ex: se a posição abaixo está livre) e atualizar a sua
	 * própria posição se for o caso.
	 */
	void applyGravity();
	
}