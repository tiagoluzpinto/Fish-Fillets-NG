package interfaces;

import objects.GameCharacter;
import pt.iscte.poo.utils.Direction;

/**
 * Interface para todos os GameObjects que podem ser empurrados
 * por um GameCharacter.
 */
public interface IsPushable {

	/**
	 * Verifica se o objeto pode ser empurrado por um 'pusher' 
	 * na direção 'dir'.
	 * * Esta lógica será complexa e específica para cada objeto. 
	 * Por exemplo, uma Âncora tem regras diferentes de uma Taça 
	 * @param pusher O GameCharacter que está a tentar empurrar.
	 * @param dir A direção do movimento.
	 * @return true se o objeto pôde ser movido, false caso contrário.
	 */
	boolean canBePushed(GameCharacter pusher, Direction dir);
	
}