package objects;

import interfaces.IsPushable;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Anchor extends MovableObject {

    private boolean hasBeenMovedHorizontally = false;

    public Anchor(Point2D position, Room room) {
        super(position, room);
    }

    @Override
    public String getName() {
        return "anchor";
    }

    @Override
    public int getLayer() {
        return 2;
    }

    @Override
    public void onGravityCollision(GameObject objBelow) {
        // Lógica de esmagar Tronco e Peixe Pequeno
        if (objBelow instanceof Trunk) {
            getRoom().removeObject(objBelow);
            setPosition(objBelow.getPosition());
        } else if (objBelow instanceof SmallFish) {
            ImageGUI.getInstance().showMessage("Game Over", "A âncora esmagou o Peixe Pequeno!");
            getRoom().getGameEngine().restartLevel();
        }
    }

    @Override
    public boolean canBePushed(GameCharacter pusher, Direction dir) {
        // 1. Peixe Pequeno NÃO move
        if (pusher instanceof SmallFish) return false;

        // 2. Só move na Horizontal
        if (dir == Direction.UP || dir == Direction.DOWN) return false;

        // 3. Só move SE ainda não tiver sido movida
        if (hasBeenMovedHorizontally) return false;

        Point2D newPos = getPosition().plus(dir.asVector());
        GameObject targetObj = getRoom().getTopmostObjectAt(newPos);

        // CASO A: Caminho Livre
        if (targetObj == null || targetObj instanceof Water) {
            setPosition(newPos);
            hasBeenMovedHorizontally = true; // Bloqueia para sempre
            return true;
        }

        // CASO B: Empurrar em Cadeia)
        // Se o objeto ao lado for empurrável (ex: outra âncora virgem ou uma pedra)
        if (pusher instanceof BigFish && targetObj instanceof IsPushable) {
            boolean nextMoved = ((IsPushable) targetObj).canBePushed(pusher, dir);
            if (nextMoved) {
                setPosition(newPos);
                hasBeenMovedHorizontally = true; // Também conta como movimento!
                return true;
            }
        }

        return false;
    }
}