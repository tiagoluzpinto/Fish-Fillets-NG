package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class BigFish extends GameCharacter {

	private static BigFish bf = new BigFish(null);

	private BigFish(Room room) {
		super(room);
		this.currentImageName = "bigFishLeft";
	}

	public static BigFish getInstance() {
		return bf;
	}

	@Override
	protected void updateImage(Direction dir) {
		if (dir == Direction.LEFT) currentImageName = "bigFishLeft";
		else if (dir == Direction.RIGHT) currentImageName = "bigFishRight";
	}

	@Override
	protected boolean handleSpecificCollisions(GameObject obj, Point2D newPosition) {
		
		// Bloqueia no Peixe Pequeno
		if (obj instanceof SmallFish) {
			return true; 
		}

		// Bloqueia na Parede com Buraco
		if (obj instanceof HoledWall) {
			return true; 
		}

		// Morre na Armadilha com Pop-up
		if (obj instanceof Trap) {
			// 1. Mostra o Pop-up (O código espera aqui até o jogador clicar OK)
			pt.iscte.poo.gui.ImageGUI.getInstance().showMessage("Game Over", "O Peixe Grande caiu na armadilha!");
			
			// 2. Reinicia o nível
			getRoom().getGameEngine().restartLevel();
			return true; 
		}

		return false; 
	}

	@Override
	protected boolean canPassThrough(GameObject obj) {
		// Pergunta: Consigo passar HoledWall? Não.
		if (obj instanceof HoledWall) {
			return false;
		}
		// Pergunta: Consigo passar Trap? Sim (para poder morrer nela).
		if (obj instanceof Trap) {
			return true;
		}
		return false;
	}
}