package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public class Bomb extends MovableObject {

	public Bomb(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "bomb";
	}
	
	@Override
	public int getLayer() {
		return 2;
	}

	@Override
    public void onGravityCollision(GameObject objBelow) {
        // REGRA: Explode em contacto com um objeto ao cair
        
        boolean isSafeSupport = (objBelow instanceof GameCharacter || 
                                 objBelow instanceof SteelHorizontal || 
                                 objBelow instanceof SteelVertical);

        if (isFalling && !isSafeSupport) {
            explode();
        }
    }
    
    private void explode() {
        Vector2D[] offsets = {
            new Vector2D(0, 0), new Vector2D(0, -1), new Vector2D(0, 1), 
            new Vector2D(-1, 0), new Vector2D(1, 0)
        };

        for (Vector2D offset : offsets) {
            Point2D targetPos = getPosition().plus(offset);
            
            if (targetPos.getX() < 0 || targetPos.getX() >= 10 || 
                targetPos.getY() < 0 || targetPos.getY() >= 10) continue;

            GameObject targetObj = getRoom().getTopmostObjectAt(targetPos);
            
            getRoom().addObject(new Explosion(targetPos, getRoom()));

            if (targetObj != null) {
                if (targetObj instanceof GameCharacter) {
                    ImageGUI.getInstance().showMessage("Game Over", "BOOM! Um peixe explodiu.");
                    getRoom().getGameEngine().restartLevel();
                    return;
                }
                if (!(targetObj instanceof Water) && !(targetObj instanceof Explosion)) {
                    getRoom().removeObject(targetObj);
                }
            }
        }
        getRoom().removeObject(this);
    }

	@Override
	public boolean canBePushed(GameCharacter pusher, Direction dir) {
		// REGRA: Não explode ao ser empurrada
		
		Point2D newPos = getPosition().plus(dir.asVector());
		GameObject targetObj = getRoom().getTopmostObjectAt(newPos);

		if (targetObj == null || targetObj instanceof Water) {
			setPosition(newPos);
			return true;
		}
		
		// Empurrar em cadeia (Apenas Peixe Grande)
		if (pusher instanceof BigFish && dir.asVector().getX() != 0 && targetObj instanceof interfaces.IsPushable) {
			boolean nextMoved = ((interfaces.IsPushable) targetObj).canBePushed(pusher, dir);
			if (nextMoved) {
				setPosition(newPos);
				return true;
			}
		}
		return false;
	}
}