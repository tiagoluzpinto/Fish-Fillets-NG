package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Buoy extends MovableObject {

	public Buoy(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "buoy";
	}

	@Override
	public int getLayer() {
		return 2;
	}

	/**
	 * A Boia tem uma gravidade invertida (sobe), exceto se tiver carga.
	 */
	@Override
    public void applyGravity() {
        // REGRA: "Afunda no caso de suportar qualquer objeto móvel."
        if (this.hasObjectOnTop()) {
            super.applyGravity(); 
            return;
        }

        // REGRA: "tenta movimentar-se em direção à superfície"
        Point2D positionAbove = getPosition().plus(Direction.UP.asVector());
        
        if (positionAbove.getY() < 0) return;

        GameObject objAbove = getRoom().getTopmostObjectAt(positionAbove);

        // Se o caminho para cima estiver livre (Água ou Vazio), sobe
        if (objAbove == null || objAbove instanceof Water) {
            setPosition(positionAbove);
        } 
    }

    @Override
    public boolean canBePushed(GameCharacter pusher, Direction dir) {
        // REGRA: "Pode ser empurrada por ambos os peixes na horizontal." 
        if (dir == Direction.LEFT || dir == Direction.RIGHT) {
            return checkHorizontalPush(pusher, dir);
        }

        // REGRA: "Pode ser empurrada para baixo apenas pelo peixe grande."
        if (dir == Direction.DOWN) {
            if (pusher instanceof BigFish) {
                Point2D newPos = getPosition().plus(dir.asVector());
                GameObject target = getRoom().getTopmostObjectAt(newPos);
                if (target == null || target instanceof Water) {
                    setPosition(newPos);
                    return true;
                }
            }
            return false; 
        }

        return false; 
    }

	@Override
	public void onGravityCollision(GameObject objBelow) {
		// A boia não mata ninguém ao cair (é leve), apenas pousa.
	}

	
	
	// Método auxiliar para não repetir código de empurrar horizontal (semelhante a Cup/Rock)
	private boolean checkHorizontalPush(GameCharacter pusher, Direction dir) {
		Point2D newPos = getPosition().plus(dir.asVector());
		GameObject targetObj = getRoom().getTopmostObjectAt(newPos);

		if (targetObj == null || targetObj instanceof Water || targetObj instanceof HoledWall) {
			setPosition(newPos);
			return true;
		}
		return false;
	}
}