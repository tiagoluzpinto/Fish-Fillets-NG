package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public class Crab extends MovableObject {

	public Crab(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "krab";
	}

	@Override
	public int getLayer() {
		return 2;
	}

	/**
	 * Chamado pelo GameEngine sempre que um peixe se move.
	 */
	public void moveRandomly() {
		// REGRA: "Mexe-se, aleatoriamente, para a esquerda/direita"
		double random = Math.random();
		Direction moveDir = null;

		if (random < 0.5) moveDir = Direction.LEFT;
		else moveDir = Direction.RIGHT;

		Point2D newPos = getPosition().plus(moveDir.asVector());
		GameObject target = getRoom().getTopmostObjectAt(newPos);

		// REGRA: "é pequeno (i.e., atravessa a parede com buraco)"
		boolean isFree = (target == null || target instanceof Water || target instanceof HoledWall);
		
		if (isFree) {
			setPosition(newPos);
			return;
		}

		// REGRA: "mata o peixe pequeno se tocar nele (ou vice versa)" [image_bd54e0.png]
		if (target instanceof SmallFish) {
			ImageGUI.getInstance().showMessage("Game Over", "O Caranguejo apanhou o Peixe Pequeno!");
			getRoom().getGameEngine().restartLevel();
		}
		// REGRA: "é morto se tocar no peixe grande ou na armadilha"
		else if (target instanceof BigFish || target instanceof Trap) {
			getRoom().removeObject(this); // Caranguejo morre
		}
	}

	@Override
	public void onGravityCollision(GameObject objBelow) {
		// Cair em cima de coisas
		if (objBelow instanceof SmallFish) {
			ImageGUI.getInstance().showMessage("Game Over", "O Caranguejo caiu em cima do Peixe Pequeno!");
			getRoom().getGameEngine().restartLevel();
		}
		else if (objBelow instanceof BigFish || objBelow instanceof Trap) {
			getRoom().removeObject(this); // Morre na colisão
		}
	}

	@Override
	public boolean canBePushed(GameCharacter pusher, Direction dir) {
		// REGRA: "não pode ser empurrado"
		return false;
	}
}