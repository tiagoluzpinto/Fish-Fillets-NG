package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Cup extends MovableObject {

	public Cup(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "cup";
	}

	@Override
	public int getLayer() {
		return 2;
	}

	@Override
	public void onGravityCollision(GameObject objBelow) {
		// A Taça não parte nada nem mata ninguém ao cair.
		// Simplesmente para (comportamento padrão herdado ao não fazer nada aqui).
	}

	@Override
	public boolean canBePushed(GameCharacter pusher, Direction dir) {
		// REGRA: Peixe Pequeno só move se não tiver nada em cima
		if (pusher instanceof SmallFish && this.hasObjectOnTop()) {
			return false;
		}

		Point2D newPos = getPosition().plus(dir.asVector());
		GameObject targetObj = getRoom().getTopmostObjectAt(newPos);

		// Pode entrar em HoledWall [cite: 75]
		if (targetObj instanceof HoledWall) {
			setPosition(newPos);
			return true;
		}

		// Espaço Livre
		if (targetObj == null || targetObj instanceof Water) {
			setPosition(newPos);
			return true;
		}
		
		// Empurrar em cadeia
		if (pusher instanceof BigFish && dir.asVector().getX() != 0 && targetObj instanceof interfaces.IsPushable) {
			boolean nextMoved = ((interfaces.IsPushable) targetObj).canBePushed(pusher, dir);
			if (nextMoved) {
				setPosition(newPos);
				return true;
			}
		}

		return false;
	}
}