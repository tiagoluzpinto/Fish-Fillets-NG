package objects;

import interfaces.IsAffectedByGravity;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public class Explosion extends GameObject implements IsAffectedByGravity {

	private int lifeTime = 1; // Dura apenas 1 tick (instante)

	public Explosion(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "explosionEffect"; // Certifica-te que tens a imagem explosionEffect.png
	}

	@Override
	public int getLayer() {
		return 1; 
	}

	@Override
	public void applyGravity() {
		// Usamos o ciclo de gravidade como um relógio
		if (lifeTime > 0) {
			lifeTime--;
		} else {
			getRoom().removeObject(this); 
		}
	}
}