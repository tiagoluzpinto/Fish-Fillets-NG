package objects;

import java.util.List;
import interfaces.IsPushable;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;
import pt.iscte.poo.utils.Vector2D;

public abstract class GameCharacter extends GameObject {

	protected String currentImageName;
	
	// Estado para saber se o peixe já saiu do nível
	private boolean hasEscaped = false;

	private int moves = 0;
	
	public GameCharacter(Room room) {
		super(room);
	}

	@Override
	public String getName() {
		return currentImageName;
	}

	// Layer 3 garante que o peixe é desenhado por cima de tudo (chão, itens, etc.)
	@Override
	public int getLayer() {
		return 3;
	}

	public int getMoves() {
		return this.moves;
	}
	
	/**
	 * Verifica se o peixe está a suportar algum objeto.
	 * Útil para impedir que o peixe empurre coisas enquanto carrega outras.
	 */
	public GameObject getObjectBeingSupported() {
		Point2D positionAbove = getPosition().plus(Direction.UP.asVector());
		GameObject obj = getRoom().getTopmostObjectAt(positionAbove);

		if (obj instanceof IsPushable && !(obj instanceof GameCharacter)) {
			return obj;
		}
		return null;
	}

	public void move(Vector2D dir) {
        Point2D currentPosition = getPosition();
        if (currentPosition == null) return;

        Direction direction = Direction.forVector(dir);
        Point2D newPosition = currentPosition.plus(dir);

        // 1. Atualizar Imagem (Direita/Esquerda)
        updateImage(direction);

        // 2. Verificar Limites do Mapa
        if (newPosition.getX() < 0 || newPosition.getX() >= 10 || 
            newPosition.getY() < 0 || newPosition.getY() >= 10) {
            return;
        }

        GameObject obj = getRoom().getTopmostObjectAt(newPosition);

        // 3. Espaço Vazio ou Água (Movimento Livre)
        if (obj == null || obj instanceof Water) {
            setPosition(newPosition);
            moves++;
            checkEscape(newPosition); // Verifica se esta posição é uma saída
            return;
        }

        // 4. Interações Específicas (Delegado para as subclasses: SmallFish/BigFish)
        if (handleSpecificCollisions(obj, newPosition)) {
            return;
        }

        // 5. Colisões Duras (Paredes e Tubos)
        if (obj instanceof Wall || obj instanceof SteelHorizontal || obj instanceof SteelVertical) {
            return;
        }

        // 6. Empurrar Objetos
        if (obj instanceof IsPushable) {
            GameObject supported = getObjectBeingSupported();
            if (supported != null && !obj.equals(supported)) return;

            List<GameObject> objectsAtDest = getRoom().getObjectsAt(newPosition);
            for (GameObject other : objectsAtDest) {
                if (other.equals(obj)) continue;
                if (other instanceof Water) continue;
                if (other instanceof Wall || other instanceof SteelHorizontal || other instanceof SteelVertical) return;
                if (!canPassThrough(other)) return;
            }

            boolean didObjectMove = ((IsPushable) obj).canBePushed(this, direction);

            if (didObjectMove) {
                setPosition(newPosition);
                moves++;
                checkEscape(newPosition);
            }
            return;
        }
    }

    // Corrigido: checkEscape sem espaços invisíveis
    protected void checkEscape(Point2D position) {
        if (position.getX() == 0 || position.getX() == 9 || 
            position.getY() == 0 || position.getY() == 9) {
            this.hasEscaped = true;
        }
    }

    // Corrigido: reset agora zera os movimentos
    public void reset() {
        this.hasEscaped = false;
        this.moves = 0; 
    }

	public boolean hasEscaped() {
		return hasEscaped;
	}

	protected abstract void updateImage(Direction dir);
	protected abstract boolean handleSpecificCollisions(GameObject obj, Point2D newPosition);
	protected abstract boolean canPassThrough(GameObject obj);
}