package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public abstract class GameObject implements ImageTile {
	
	private Point2D position;
	private Room room;
	
	public GameObject(Room room) {
		this.room = room;
	}
	
	public GameObject(Point2D position, Room room) {
		this.position = position;
		this.room = room;
	}

	/// Verifica se existe algum objeto EMPURRÁVEL em cima deste
	// (Ignora Paredes, Tubos, Água, etc.)
	public boolean hasObjectOnTop() {
		Point2D posAbove = getPosition().plus(Direction.UP.asVector());
		// garantir que a Room tem o método getTopmostObjectAt
		GameObject obj = getRoom().getTopmostObjectAt(posAbove);
		
		// Só devolve true se o objeto em cima for "IsPushable" (Taça, Pedra, etc.)
		// Assim, tetos (Paredes) não contam como peso.
		return (obj != null && obj instanceof interfaces.IsPushable);
	}

	public void setPosition(int i, int j) {
		position = new Point2D(i, j);
	}
	
	public void setPosition(Point2D position) {
		this.position = position;
	}

	@Override
	public Point2D getPosition() {
		return position;
	}
	
	public Room getRoom() {
		return room;
	}
	
	public void setRoom(Room room) {
		this.room = room;
	}
}