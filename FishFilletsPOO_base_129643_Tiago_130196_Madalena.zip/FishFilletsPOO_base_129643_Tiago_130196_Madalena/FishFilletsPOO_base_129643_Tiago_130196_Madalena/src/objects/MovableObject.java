package objects;

import interfaces.IsAffectedByGravity;
import interfaces.IsPushable;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

/**
 * Classe base para todos os objetos que se movem (sofrem gravidade e podem ser empurrados).
 * Implementa o "Template Method" para a gravidade.
 */
public abstract class MovableObject extends GameObject implements IsPushable, IsAffectedByGravity {

	// Flag para saber se o objeto está num movimento de queda (útil para a Bomba)
	protected boolean isFalling = false;

	public MovableObject(Point2D position, Room room) {
		super(position, room);
	}

	/**
	 * TEMPLATE METHOD: Define a estrutura do algoritmo da gravidade.
	 */
	@Override
    public void applyGravity() {
        Point2D positionBelow = getPosition().plus(Direction.DOWN.asVector());
        
        if (positionBelow.getY() >= 10) return;

        GameObject objBelow = getRoom().getTopmostObjectAt(positionBelow);

        // 1. Caminho Livre (Nada ou Água) -> CAI
        if (objBelow == null || objBelow instanceof Water) {
            setPosition(positionBelow);
            isFalling = true; 
        } 
        // 2. Obstáculo encontrado
        else {
            onGravityCollision(objBelow);
            
            if (getPosition().getY() != positionBelow.getY()) {
                // (Caso especial: se partiu um tronco e desceu)
            } else {
                isFalling = false;
            }
        }
    }

	/**
	 * As subclasses implementam o que acontece quando aterram em algo.
	 * @param objBelow O objeto em que acabaram de embater.
	 */
	public abstract void onGravityCollision(GameObject objBelow);
}