package objects;

import interfaces.IsPushable;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Rock extends MovableObject {

	// Controla se o caranguejo já foi criado por esta pedra
	private boolean hasSpawnedCrab = false;

	public Rock(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "stone";
	}

	@Override
	public int getLayer() {
		return 2;
	}

	@Override
    public void onGravityCollision(GameObject objBelow) {
        // 1. Esmagar Tronco
        if (objBelow instanceof Trunk) {
            getRoom().removeObject(objBelow); 
            setPosition(objBelow.getPosition()); 
        }
        
        // 2. Esmagar Peixe Pequeno
        else if (objBelow instanceof SmallFish) {
            ImageGUI.getInstance().showMessage("Game Over", "O Peixe Pequeno foi esmagado por uma pedra!");
            getRoom().getGameEngine().restartLevel();
        }
    }

	@Override
	public boolean canBePushed(GameCharacter pusher, Direction dir) {
		// 1. Peixe Pequeno: Não empurra pesados
		if (pusher instanceof SmallFish) return false;

		// 2. Peixe Grande
		if (pusher instanceof BigFish) {
			Point2D newPos = getPosition().plus(dir.asVector());
			GameObject targetObj = getRoom().getTopmostObjectAt(newPos);
			
			boolean canMove = false;

			// A. Caminho Livre
			if (targetObj == null || targetObj instanceof Water) {
				canMove = true;
			}
			// B. Empurrar em Cadeia (Recursivo)
			else if (dir.asVector().getX() != 0 && targetObj instanceof IsPushable) {
				boolean nextMoved = ((IsPushable) targetObj).canBePushed(pusher, dir);
				if (nextMoved) {
					canMove = true;
				}
			}

			// Se validámos que a pedra se vai mexer, verificamos a regra do Caranguejo
			if (canMove) {
				// Lógica de Spawn do Caranguejo
				// "é criado... na primeira vez que esta é movimentada horizontalmente"
				if (!hasSpawnedCrab && dir.asVector().getY() == 0) {
					spawnCrab();
					hasSpawnedCrab = true; // Garante que só cria uma vez
				}

				setPosition(newPos);
				return true;
			}
		}
		return false;
	}

	private void spawnCrab() {
		Point2D posAbove = getPosition().plus(Direction.UP.asVector());
		GameObject objAbove = getRoom().getTopmostObjectAt(posAbove);

		// "Não é criado se a posição por cima da pedra não estiver livre"
		if (objAbove == null || objAbove instanceof Water) {
			// Cria o inimigo e adiciona à sala
			Crab c = new Crab(posAbove, getRoom());
			getRoom().addObject(c);
		}
	}
}