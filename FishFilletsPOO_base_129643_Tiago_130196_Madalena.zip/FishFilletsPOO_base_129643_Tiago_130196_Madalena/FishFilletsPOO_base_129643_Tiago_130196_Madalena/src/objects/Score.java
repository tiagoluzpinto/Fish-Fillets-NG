package objects;

/**
 * Representa uma pontuação do jogador, combinando tempo e movimentos.
 * Implementa Comparable para permitir a ordenação (o menor tempo é o melhor).
 */
public class Score implements Comparable<Score> {

    private final long timeInNanos;
    private final int movements;
    private final String name;

    public Score(long timeInNanos, int movements, String name) {
        this.timeInNanos = timeInNanos;
        this.movements = movements;
        this.name = name;
    }

    public long getTimeInNanos() {
        return timeInNanos;
    }

    public int getMovements() {
        return movements;
    }
    
    public String getPlayerName() {
    	return name;
    }

    /**
     * Define a regra de comparação:
     * 1. Compara primeiro pelo tempo (menor tempo é melhor).
     * 2. Se os tempos forem iguais, compara pelos movimentos (menos movimentos é melhor).
     */
    @Override
    public int compareTo(Score other) {
        // Compara pelo tempo em nanosegundos (ordem crescente)
        int timeComparison = Long.compare(this.timeInNanos, other.timeInNanos);
        
        if (timeComparison != 0) {
            return timeComparison;
        }
        
        // Se os tempos forem iguais, compara pelo número de movimentos (ordem crescente)
        return Integer.compare(this.movements, other.getMovements());
    }
    
    // Método para guardar no ficheiro (tempo;movimentos)
    @Override
    public String toString() {
        return timeInNanos + ";" + movements + ";" + name; // CORRIGIDO: Inclui o nome
    }

    // Métodos essenciais para Listas e Coleções
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Score score = (Score) o;
        return timeInNanos == score.timeInNanos && movements == score.movements;
    }
}