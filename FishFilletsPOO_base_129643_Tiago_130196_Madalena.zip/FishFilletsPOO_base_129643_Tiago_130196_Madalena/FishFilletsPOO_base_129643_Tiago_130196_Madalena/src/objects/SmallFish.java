package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class SmallFish extends GameCharacter {

	// Singleton (Instancia logo, mas com room a null que será atualizada no Room.readRoom)
	private static SmallFish instance = new SmallFish(null);

	private SmallFish(Room room) {
		super(room);
		this.currentImageName = "smallFishLeft"; // Define imagem inicial
	}

	public static SmallFish getInstance() {
		return instance;
	}

	@Override
	protected void updateImage(Direction dir) {
		if (dir == Direction.LEFT) {
			currentImageName = "smallFishLeft";
		} else if (dir == Direction.RIGHT) {
			currentImageName = "smallFishRight";
		}
	}

	@Override
	protected boolean handleSpecificCollisions(GameObject obj, Point2D newPosition) {
		// REGRA: Bloqueia no outro peixe (não pode atravessar)
		if (obj instanceof BigFish) {
			return true;
		}

		// REGRA: Atravessa Parede com Buraco e Armadilha
		if (obj instanceof HoledWall || obj instanceof Trap) {
			setPosition(newPosition);
			
			// IMPORTANTE: Verificar se esta posição é uma saída
			// (Requer que o método checkEscape seja protected na classe GameCharacter)
			checkEscape(newPosition); 
			
			return true; // Retornamos true para dizer "já tratei do movimento, não faças mais nada"
		}

		return false; // Deixa o comportamento padrão lidar com o resto (paredes normais, vazio, etc.)
	}

	@Override
	protected boolean canPassThrough(GameObject obj) {
		// Método auxiliar usado para validar empurrões ou movimentos complexos.
		// O Peixe Pequeno consegue passar através destes objetos:
		if (obj instanceof HoledWall || obj instanceof Trap) {
			return true;
		}
		return false;
	}
}