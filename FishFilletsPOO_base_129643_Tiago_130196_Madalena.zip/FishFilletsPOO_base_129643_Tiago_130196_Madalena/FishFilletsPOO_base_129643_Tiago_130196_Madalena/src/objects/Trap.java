package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

// CORREÇÃO: Herda de MovableObject porque está na lista de objetos móveis [cite: 65]
// e sofre gravidade.
public class Trap extends MovableObject {

	public Trap(Point2D position, Room room) {
		super(position, room);
	}

	@Override
	public String getName() {
		return "trap";
	}

	@Override
	public int getLayer() {
		return 2; // Camada de objetos móveis
	}

	@Override
	public void onGravityCollision(GameObject objBelow) {
		// 1. Esmaga Tronco (É um objeto pesado)
		if (objBelow instanceof Trunk) {
			getRoom().removeObject(objBelow);
			setPosition(objBelow.getPosition());
		}
		
		// 2. Colisão com Peixe Grande -> MORTE
		// "em caso de colisão com o peixe grande provoca a morte" 
		else if (objBelow instanceof BigFish) {
			ImageGUI.getInstance().showMessage("Game Over", "A armadilha caiu em cima do Peixe Grande!");
			getRoom().getGameEngine().restartLevel();
		}

		// 3. Colisão com Peixe Pequeno -> MORTE (Esmagado pelo peso)
		// Embora ele atravesse lateralmente, verticalmente o peso mata-o 
		else if (objBelow instanceof SmallFish) {
			ImageGUI.getInstance().showMessage("Game Over", "O Peixe Pequeno foi esmagado pela armadilha!");
			getRoom().getGameEngine().restartLevel();
		}
	}

	@Override
	public boolean canBePushed(GameCharacter pusher, Direction dir) {
		// O Peixe Pequeno não empurra objetos pesados 
		if (pusher instanceof SmallFish) return false;

		// O Peixe Grande morre se colidir com a armadilha 
		// Portanto, se tentar empurrar, morre.
		if (pusher instanceof BigFish) {
			ImageGUI.getInstance().showMessage("Game Over", "O Peixe Grande tocou na armadilha!");
			getRoom().getGameEngine().restartLevel();
			return false;
		}

		return false;
	}
}