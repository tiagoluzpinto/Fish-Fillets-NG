package pt.iscte.poo.game;

import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import interfaces.IsAffectedByGravity;
import objects.BigFish;
import objects.Crab;
import objects.GameCharacter;
import objects.GameObject;
import objects.SmallFish;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.observer.Observed;
import pt.iscte.poo.observer.Observer;
import pt.iscte.poo.utils.Direction;

public class GameEngine implements Observer {

	private Room currentRoom;
	private int lastTickProcessed = 0;
	private GameCharacter selectedFish;
	private int currentLevelIndex = 0;
	private long startTimeNano;

	public GameEngine() {
		File file = new File("./rooms/room0.txt");
		if (file.exists()) {
			currentRoom = Room.readRoom(file, this);
		} else {
			System.err.println("ERRO: room0.txt não encontrado!");
		}
		this.selectedFish = SmallFish.getInstance();
		this.startTimeNano = System.nanoTime();
		
		updateGUI();
	}

	@Override
	public void update(Observed source) {
		// --- 1. PROCESSAR INPUT (JOGADOR) ---
		if (ImageGUI.getInstance().wasKeyPressed()) {
			int key = ImageGUI.getInstance().keyPressed();

			if (key == KeyEvent.VK_SPACE) {
				// Trocar de Peixe
				if (selectedFish == SmallFish.getInstance()) {
					selectedFish = BigFish.getInstance();
				} else {
					selectedFish = SmallFish.getInstance();
				}
				String nome = (selectedFish instanceof SmallFish) ? "Peixe Pequeno" : "Peixe Grande";
				ImageGUI.getInstance().setStatusMessage("Selecionado: " + nome);

			} else if (key == KeyEvent.VK_R) {
				restartLevel();

			} else {
				// Movimento
				Direction dir = Direction.directionFor(key);
				if (dir != null && !selectedFish.hasEscaped()) {
					selectedFish.move(dir.asVector());
			
					// Atualizar a barra de status com o número de movimentos
					String nome = (selectedFish instanceof SmallFish) ? "Peixe Pequeno" : "Peixe Grande";
					ImageGUI.getInstance().setStatusMessage("Selecionado: " + nome + " | Movimentos: " + selectedFish.getMoves());
				}

				// Sempre que o peixe joga, os inimigos movem-se
				moveEnemies();
			}
		}

		// --- 2. PROCESSAR FÍSICA (TEMPO/GRAVIDADE) ---
		int t = ImageGUI.getInstance().getTicks();
		while (lastTickProcessed < t) {
			processTick();
		}

		// --- 3. ATUALIZAR GUI ---
		this.updateGUI();
		ImageGUI.getInstance().update();
	}

	private void processTick() {
		lastTickProcessed++;

		// Criar lista segura para iterar
		List<GameObject> gameObjects = new ArrayList<>();
		for (ImageTile tile : currentRoom.getObjects()) {
			if (tile instanceof GameObject) {
				gameObjects.add((GameObject) tile);
			}
		}

		// 1. Gravidade
		for (GameObject obj : gameObjects) {
			if (obj instanceof IsAffectedByGravity) {
				((IsAffectedByGravity) obj).applyGravity();
			}
		}

		// 2. Verificações de Jogo
		checkStackCrushing();
		checkFishExit(SmallFish.getInstance());
		checkFishExit(BigFish.getInstance());
		checkLevelCompletion();
	}

	// NOVO: Método para mover inimigos (Caranguejos)
	private void moveEnemies() {
		// Copiar lista para evitar erros se objetos forem removidos durante o loop
		List<GameObject> enemies = new ArrayList<>();
		for (ImageTile t : currentRoom.getObjects()) {
			if (t instanceof GameObject)
				enemies.add((GameObject) t);
		}

		for (GameObject obj : enemies) {
			if (obj instanceof Crab) {
				((Crab) obj).moveRandomly();
			}
		}
	}

	private void checkStackCrushing() {
		SmallFish sf = SmallFish.getInstance();
		if (sf.getRoom() == currentRoom && !sf.hasEscaped()) {
			GameObject directObj = sf.getObjectBeingSupported();
			if (directObj != null && directObj.hasObjectOnTop()) {
				ImageGUI.getInstance().showMessage("Game Over", "O Peixe Pequeno foi esmagado!");
				restartLevel();
				return;
			}
		}

		BigFish bf = BigFish.getInstance();
		if (bf.getRoom() == currentRoom && !bf.hasEscaped()) {
			GameObject obj1 = bf.getObjectBeingSupported();
			if ((obj1 instanceof objects.Rock || obj1 instanceof objects.Anchor) && obj1.hasObjectOnTop()) {
				ImageGUI.getInstance().showMessage("Game Over", "O Peixe Grande foi esmagado!");
				restartLevel();
			}
		}
	}

	private void checkFishExit(GameCharacter fish) {
		if (fish.getRoom() == currentRoom && fish.hasEscaped()) {
			List<ImageTile> currentImages = currentRoom.getObjects();
			if (currentImages.contains(fish)) {
				ImageGUI.getInstance().removeImage(fish);
				currentRoom.removeObject(fish);
				ImageGUI.getInstance().setStatusMessage(fish.getName() + " saiu!");
			}
		}
	}

	public void updateGUI() {
		if (currentRoom != null) {
			ImageGUI.getInstance().clearImages();
			ImageGUI.getInstance().addImages(currentRoom.getObjects());
		}
	}

	public Room getCurrentRoom() {
		return currentRoom;
	}

	public void restartLevel() {
		if (currentRoom == null)
			return;
		String currentRoomName = currentRoom.getName();
		File roomFile = new File("./rooms/" + currentRoomName);

		if (!roomFile.exists())
			return;

		SmallFish.getInstance().reset();
		BigFish.getInstance().reset();

		currentRoom = Room.readRoom(roomFile, this);
		selectedFish = SmallFish.getInstance();

		ImageGUI.getInstance().setStatusMessage("Nível Reiniciado!");
		updateGUI();
	}

	public void checkLevelCompletion() {
		if (SmallFish.getInstance().hasEscaped() && BigFish.getInstance().hasEscaped()) {
			nextLevel();
		}
	}

	public void nextLevel() {
		currentLevelIndex++;
		String nextRoomName = "room" + currentLevelIndex + ".txt";
		File nextRoomFile = new File("./rooms/" + nextRoomName);

		if (nextRoomFile.exists()) {
			SmallFish.getInstance().reset();
			BigFish.getInstance().reset();
			currentRoom = Room.readRoom(nextRoomFile, this);
			selectedFish = SmallFish.getInstance();
			ImageGUI.getInstance().setStatusMessage("Nível " + currentLevelIndex);
			updateGUI();
		} else {
			// FIM DE JOGO
			long finalTimeNano = System.nanoTime() - startTimeNano;
			// Correção: somar movimentos apenas das instâncias (já que moves reseta no reset())
			int totalMoves = BigFish.getInstance().getMoves() + SmallFish.getInstance().getMoves();

			// 1. Pede o nome
			String playerName = ImageGUI.getInstance().askUser("Parabéns! Terminaste!\nInsere o teu nome:");

			// 2. Guarda
			HighscoreManager.saveNewScore(finalTimeNano, totalMoves, playerName);

			// 3. Mostra a tabela (isto deve bloquear a execução até fechar o popup)
			HighscoreManager.displayHighscores();

			// 4. Mata o processo
			System.exit(0);
		}
	}
}