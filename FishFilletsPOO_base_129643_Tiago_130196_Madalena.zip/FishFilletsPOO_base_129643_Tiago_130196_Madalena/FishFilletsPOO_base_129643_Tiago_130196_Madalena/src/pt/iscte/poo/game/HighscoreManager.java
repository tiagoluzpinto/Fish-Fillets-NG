package pt.iscte.poo.game;

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale; // Necessário para formatar double com ponto

import objects.Score;
import pt.iscte.poo.gui.ImageGUI;

public class HighscoreManager {

    private static final String HIGHSCORE_FILE = "highscores.txt";
    private static final int MAX_SCORES = 10;
    private static final String SEPARATOR = ";";

    // Nota: Removi as variáveis estáticas 'allScores' e 'newScore'
    // A lista deve ser sempre lida do ficheiro no saveNewScore para garantir que está atualizada.

    /**
     * PROCEDIMENTO PRINCIPAL:
     * 1. Lê todos os scores existentes do ficheiro.
     * 2. Adiciona o novo Score.
     * 3. Ordena a lista.
     * 4. Retém apenas os 10 melhores e reescreve o ficheiro.
     * @param newTimeInNanos O tempo de execução do nível em nanosegundos.
     * @param movements O número de movimentos do jogador.
     */
    public static void saveNewScore(long newTimeInNanos, int movements, String name) {
        Score newScore = new Score(newTimeInNanos, movements, name);
        
        System.out.println("-> Processando novo score: " + newScore.getTimeInNanos() + "ns, Movimentos: " + newScore.getMovements());

        // 1. Ler todos os scores existentes
        List<Score> allScores = readAllScores();

        // 2. Adicionar o novo score
        allScores.add(newScore);

        // 3. Ordenar a lista (Usa Score.compareTo() por defeito)
        Collections.sort(allScores);
        
        // 4. Determinar quantos scores manter (máximo de 10)
        int scoresToKeep = Math.min(allScores.size(), MAX_SCORES);

        // 5. Reescrever o ficheiro com os 'N' melhores scores
        writeBestScores(allScores.subList(0, scoresToKeep));
    }

    // --- PROCEDIMENTOS DE FICHEIRO ---

    private static List<Score> readAllScores() {
        List<Score> scores = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(HIGHSCORE_FILE))) { 
            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String[] parts = line.split(SEPARATOR);
                    if (parts.length == 3) {
                        long time = Long.parseLong(parts[0].trim());
                        int movements = Integer.parseInt(parts[1].trim());
                        String playerName = parts[2].trim();
                        scores.add(new Score(time, movements, playerName));
                    }
                } catch (NumberFormatException e) {
                    System.err.println("Aviso: Linha de score inválida ignorada: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Aviso: Ficheiro " + HIGHSCORE_FILE + " não encontrado. Será criado.");
        } catch (IOException e) {
            System.err.println("Erro de leitura: " + e.getMessage());
        }
        return scores;
    }

    private static void writeBestScores(List<Score> bestScores) {
        // O argumento 'false' no FileWriter garante que o ficheiro é truncado (reescrito)
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(HIGHSCORE_FILE, false))) {
            
            for (Score score : bestScores) {
                // Usa o método toString() da classe Score, que devolve "tempo;movimentos"
                bw.write(score.toString());
                bw.newLine(); 
            }
            System.out.println("-> Ficheiro " + HIGHSCORE_FILE + " atualizado com " + bestScores.size() + " scores.");
        } catch (IOException e) {
            System.err.println("Erro de escrita: " + e.getMessage());
        }
    }

    // --- APRESENTAÇÃO DE SCORES ---

    public static void displayHighscores() {
        // Lemos a lista ordenada do ficheiro
        List<Score> scores = readAllScores();
        
        if (scores.isEmpty()) {
            ImageGUI.getInstance().showMessage("Highscores", "Nenhum score guardado ainda.");
            return;
        }

        // 1. Apresentar o Score Atual (após ler a lista completa)
        // O último score guardado é o que acabámos de processar, mas para simplificar, 
        // usaremos o último score na lista ordenada (o melhor) ou lido.
        
        // Em vez de apresentar apenas o seu score, vamos mostrar a tabela completa:
        
        StringBuilder sb = new StringBuilder();
        sb.append("--- TOP 10 HIGH SCORES ---\n");
        
        // NOVO: A tabela inclui a coluna Nome
        sb.append(String.format("%-5s | %-15s | %-8s | %s\n", "Rank", "Jogador", "Tempo (s)", "Movs")); 
        sb.append("--------------------------------------------------\n");
        
        int rank = 1;
        for (Score score : scores) {
            double timeInSeconds = score.getTimeInNanos() / 1_000_000_000.0;
            
            // NOVO: Formatação para incluir o nome
            sb.append(String.format(Locale.US, "%-5d | %-15s | %-8.2f | %d\n", 
                rank++, score.getPlayerName(), timeInSeconds, score.getMovements()));
        }

        ImageGUI.getInstance().showMessage("Tabela de Highscores", sb.toString());
    }
}