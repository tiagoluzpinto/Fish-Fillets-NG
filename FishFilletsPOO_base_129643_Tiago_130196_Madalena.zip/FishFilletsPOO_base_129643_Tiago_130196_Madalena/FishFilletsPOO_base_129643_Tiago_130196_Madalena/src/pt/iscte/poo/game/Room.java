package pt.iscte.poo.game;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import objects.*; // Certifica-te que Buoy e Crab estão neste package
import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Point2D;

public class Room {
	
	private List<GameObject> objects;
	private String roomName;
	private GameEngine engine;
	
	// Posições iniciais (úteis se precisarmos de resetar sem reler ficheiro)
	private Point2D smallFishStartingPosition;
	private Point2D bigFishStartingPosition;
	
	public Room(GameEngine engine) {
		this.engine = engine;
		this.objects = new ArrayList<GameObject>();
	}
	
	public GameEngine getGameEngine() {
		return this.engine;
	}

	public String getName() {
		return roomName;
	}
	
	public void setName(String name) {
		this.roomName = name;
	}

	public void addObject(GameObject obj) {
		objects.add(obj);
	}
	
	public void removeObject(GameObject obj) {
		objects.remove(obj);
	}
	
	public List<ImageTile> getObjects() {
		return new ArrayList<ImageTile>(objects);
	}

	public GameObject getTopmostObjectAt(Point2D position) {
		if (position.getX() < 0 || position.getX() >= 10 || position.getY() < 0 || position.getY() >= 10) {
			return null;
		}
		GameObject highestObj = null;
		int maxLayer = -1;

		for (GameObject obj : objects) {
			if (obj.getPosition().equals(position)) {
				if (obj.getLayer() > maxLayer) {
					maxLayer = obj.getLayer();
					highestObj = obj;
				}
			}
		}
		return highestObj;
	}
	
	// Método auxiliar para obter todos os objetos numa posição (usado no empurrar)
	public List<GameObject> getObjectsAt(Point2D position) {
		List<GameObject> found = new ArrayList<>();
		for (GameObject obj : objects) {
			if (obj.getPosition().equals(position)) {
				found.add(obj);
			}
		}
		return found;
	}

	// Setters de posição inicial
	public void setSmallFishStartingPosition(Point2D p) { this.smallFishStartingPosition = p; }
	public void setBigFishStartingPosition(Point2D p) { this.bigFishStartingPosition = p; }
	
	// --- LEITURA DE FICHEIRO ATUALIZADA ---
	
	public static Room readRoom(File f, GameEngine engine) {
		Room r = new Room(engine);
		r.setName(f.getName());

		// 1. Preencher Fundo com Água
		for (int x = 0; x < 10; x++) {
			for (int y = 0; y < 10; y++) {
				r.addObject(new Water(new Point2D(x, y), r));
			}
		}

		// 2. Ler ficheiro e colocar objetos
		try (Scanner sc = new Scanner(f)) {
			int y = 0;
			while (sc.hasNextLine()) {
				String line = sc.nextLine();
				for (int x = 0; x < line.length(); x++) {
					char c = line.charAt(x);
					Point2D pos = new Point2D(x, y);

					switch (c) {
						case 'B':
							BigFish bf = BigFish.getInstance();
							bf.setPosition(pos);
							bf.setRoom(r);
							r.addObject(bf);
							r.setBigFishStartingPosition(pos);
							break;
						case 'S':
							SmallFish sf = SmallFish.getInstance();
							sf.setPosition(pos);
							sf.setRoom(r);
							r.addObject(sf);
							r.setSmallFishStartingPosition(pos);
							break;
						case 'W': r.addObject(new Wall(pos, r)); break;
						case 'H': r.addObject(new SteelHorizontal(pos, r)); break;
						case 'V': r.addObject(new SteelVertical(pos, r)); break;
						case 'X': r.addObject(new HoledWall(pos, r)); break;
						case 'Y': r.addObject(new Trunk(pos, r)); break;
						case 'C': r.addObject(new Cup(pos, r)); break;
						case 'R': r.addObject(new Rock(pos, r)); break;
						case 'A': r.addObject(new Anchor(pos, r)); break;
						case 'b': r.addObject(new Bomb(pos, r)); break;
						case 'T': r.addObject(new Trap(pos, r)); break;
						
						// --- NOVOS ELEMENTOS ---
						case 'O': r.addObject(new Buoy(pos, r)); break; // 'O' de Orb/Boia
						case 'K': r.addObject(new Crab(pos, r)); break; // Opcional para testes
					}
				}
				y++;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return r;
	}
}